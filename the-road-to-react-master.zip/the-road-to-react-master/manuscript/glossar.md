# Glossar

github
codesandbox
visual studio code (VSCode)
vanilla - e.g. vanilla HTML, JavaScript: It's purest form without sugar on top
development server
production server
browser's developer tools
bug
debugging
build tools
compiler
transpiler
bundler
function signature
parameters
arguments
PascalCase
create-react-app
Boilerplate Code
Node
npm
implementation details, business logic
rendering - other word for display
stable identifier - e.g. `id`
unstable identifier - e.g. `index`
multi-paradigm programming language - .e.g JavaScript
object-oriented programming
functional programming
declaration/definition
instanstiation - e.g. class
instance - .e.g class instance, component instance
function
class
class method, method
library
framework
dependency
refactor
declarative
programmatic
imperative
state
global state
shared state
mutable
immutable
pure function
side-effect
callback function
single page application
static site generation
server-side rendering
